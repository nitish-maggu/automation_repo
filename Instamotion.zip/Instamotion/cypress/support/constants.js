export const max_number_of_cars = 27;
export const min_number_of_cars = 0;
export const filterClassXPATH = '//div[@class="sc-iFUGim kiPcFj"]';
